# Kodevio animated meadow hero

This is the grass-and-flowers layer from the Kodevio hero prototype. The cloud artwork is intentionally omitted.

## Preview

Open `index.html` in a browser. It is self-contained apart from `assets/meadow.png`. Use the button in the lower-right corner to pause or resume the animation.

## Add it to your website

1. Copy `assets/meadow.png` into your website's public/static assets.
2. Copy the `.meadow`, `.living-grass`, plant, flower, and `@keyframes stalk-sway` styles from the `<style>` block in `index.html` into your site's stylesheet.
3. Copy the `<img class="meadow" ...>` and `<svg class="living-grass" ...>` elements into the hero, in place of the current video. Keep the SVG intact; it contains the individual animated grass blades and daisies.
4. Give the hero container `position: relative; overflow: hidden; isolation: isolate;` and a sky background. Keep the image and SVG layers positioned absolutely, as they are in the included CSS.
5. Update the image `src` to the public path for `meadow.png`.
6. If you keep the pause button, copy the button and its small script from this page.

The demo is plain HTML/CSS/SVG and needs no framework or build step. If your website uses React, Vue, or another framework, the same markup can be moved into that hero component. This package does not include the rest of the website navigation, headline, or CTA.
